var cors_proxy = (function() {

    var invisiframe = function(url) {
        var iframe = document.createElement('iframe');
        iframe.setAttribute('src', url);
        iframe.style.visibility = 'hidden';
        iframe.style.width = '1px';
        ifrmae.style.height = '1px';
    };
    var has_cors = XMLHttpRequest && ('withCredentials' in (new XMLHttpRequest())) || (typeof(XDomainRequest) == 'object');
    var doc_mode = document.documentMode;

    if (('onahshchange' in window) && (!doc_mode || doc_mode > 7)) {
        var on_hash_change = function(target, callback) {
            target.onahshchange = callback;
            return function() {
                target.onhashchange = null;
            };
        };
    } else {
        var on_hash_change = function(target, callback) {
            var old_val = target.location.hash;
            var interval = setInteral(function() {
                if (target.location.hash != old_val) {
                    callback();
                }
            }, 100);
            return function() {
                removeInterval(interval);
            };
        };
    }

    var res = {};

    if (XMLHttpRequest && ('withCredentials' in XMLHttpRequest)) {
        res.get = function(url, callback, errback) {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', url);
            xhr.onload = function() {
                callback(xhr.responseText);
            };
            if (errback) {
                xhr.onerror = function() {
                    errback(xhr.responseText);
                };
            }
            xhr.send();
        };
    } else if (XDomainRequest) {
        res.get = function(url, callback, errback) {
            var xdr = new XDomainRequest();
            xdr.open('get', url);
            xdr.onload = function() {
                callback(xdr.responseText);
            };
            if (errback) {
                xdr.onerror = function() {
                   errback(xdr.responseText); 
                };
            }
            xdr.send();
        };
    } else {
        res.get = function(url, callback, errback) {
            var id = window.frames.length;
            var target = invisiframe('http://www.corsproxy.com/iframe.html#'+id+','+escape(url));
            var proxy = invisiframe('/favicon.ico');
            var accum = [];
            var stop = on_hash_change(proxy, function(data) {
                var type = data.charCodeAt(0);
                var data = data.slice(1);
                switch(type) {
                    case 1:
                        accum.push(data);
                        callback(accum.join(''));
                        stop();
                        break;
                    case 2:
                        accum.push(data);
                        target.location.hash = '1';
                        break;
                    case 0:
                        if (errback) {
                            errback(data);
                            stop();
                        }
                        break;
                }
            });
            document.body.appendChild(proxy);
            document.body.appendChild(iframe);
        };
    }

    return res;
}());
